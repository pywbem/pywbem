
from pywbem import mof_compiler
print mof_compiler.__file__
import pdb
pdb.set_trace()
mof_compiler._build()
