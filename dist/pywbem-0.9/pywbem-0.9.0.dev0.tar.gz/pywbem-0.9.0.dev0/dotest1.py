#!/usr/bin/env python
# vim: tabstop=4 shiftwidth=4 softtabstop=4

from __future__ import print_function
import six
import pywbem

conn = pywbem.WBEMConnection('https://10.1.134.212',     # url
                             creds=('smilab', 'foosball'))     # credentials
                             
instance_names = conn.EnumerateInstanceNames('CIM_ManagedElement',
                                             namespace='interop')
