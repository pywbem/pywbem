#! python
# vim: tabstop=4 shiftwidth=4 softtabstop=4

from __future__ import print_function
import pywbem
print('issue connect')
CONN = pywbem.WBEMConnection('https://10.1.134.246',     # url
                             creds=('smilab', 'F00s4ll'),  # credentials
                             no_verification=True)
print('connected')
CLS = CONN.GetClass('CIM_ManagedElement', namespace='interop')
print('good response from EnumInstNames')
